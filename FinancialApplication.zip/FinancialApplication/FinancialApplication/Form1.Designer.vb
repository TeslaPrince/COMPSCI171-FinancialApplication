﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox = New System.Windows.Forms.GroupBox()
        Me.lblCompounds = New System.Windows.Forms.Label()
        Me.txtPrinciple = New System.Windows.Forms.TextBox()
        Me.lblYears = New System.Windows.Forms.Label()
        Me.lblPrinciple = New System.Windows.Forms.Label()
        Me.txtCompounds = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtInterest = New System.Windows.Forms.TextBox()
        Me.txtYears = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox
        '
        Me.GroupBox.Controls.Add(Me.lblCompounds)
        Me.GroupBox.Controls.Add(Me.txtPrinciple)
        Me.GroupBox.Controls.Add(Me.lblYears)
        Me.GroupBox.Controls.Add(Me.lblPrinciple)
        Me.GroupBox.Controls.Add(Me.txtCompounds)
        Me.GroupBox.Controls.Add(Me.Label1)
        Me.GroupBox.Controls.Add(Me.txtInterest)
        Me.GroupBox.Controls.Add(Me.txtYears)
        Me.GroupBox.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox.Name = "GroupBox"
        Me.GroupBox.Size = New System.Drawing.Size(291, 165)
        Me.GroupBox.TabIndex = 0
        Me.GroupBox.TabStop = False
        '
        'lblCompounds
        '
        Me.lblCompounds.AutoSize = True
        Me.lblCompounds.Location = New System.Drawing.Point(12, 99)
        Me.lblCompounds.Name = "lblCompounds"
        Me.lblCompounds.Size = New System.Drawing.Size(153, 17)
        Me.lblCompounds.TabIndex = 8
        Me.lblCompounds.Text = "Number of Compounds"
        '
        'txtPrinciple
        '
        Me.txtPrinciple.Location = New System.Drawing.Point(169, 12)
        Me.txtPrinciple.Name = "txtPrinciple"
        Me.txtPrinciple.Size = New System.Drawing.Size(100, 22)
        Me.txtPrinciple.TabIndex = 1
        '
        'lblYears
        '
        Me.lblYears.AutoSize = True
        Me.lblYears.Location = New System.Drawing.Point(12, 71)
        Me.lblYears.Name = "lblYears"
        Me.lblYears.Size = New System.Drawing.Size(115, 17)
        Me.lblYears.TabIndex = 4
        Me.lblYears.Text = "Number of Years"
        '
        'lblPrinciple
        '
        Me.lblPrinciple.AutoSize = True
        Me.lblPrinciple.Location = New System.Drawing.Point(12, 18)
        Me.lblPrinciple.Name = "lblPrinciple"
        Me.lblPrinciple.Size = New System.Drawing.Size(62, 17)
        Me.lblPrinciple.TabIndex = 0
        Me.lblPrinciple.Text = "Principle"
        '
        'txtCompounds
        '
        Me.txtCompounds.Location = New System.Drawing.Point(169, 99)
        Me.txtCompounds.Name = "txtCompounds"
        Me.txtCompounds.Size = New System.Drawing.Size(100, 22)
        Me.txtCompounds.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Annual Interest"
        '
        'txtInterest
        '
        Me.txtInterest.Location = New System.Drawing.Point(169, 41)
        Me.txtInterest.Name = "txtInterest"
        Me.txtInterest.Size = New System.Drawing.Size(100, 22)
        Me.txtInterest.TabIndex = 3
        '
        'txtYears
        '
        Me.txtYears.Location = New System.Drawing.Point(169, 71)
        Me.txtYears.Name = "txtYears"
        Me.txtYears.Size = New System.Drawing.Size(100, 22)
        Me.txtYears.TabIndex = 5
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(297, 12)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(491, 148)
        Me.ListBox1.TabIndex = 1
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(40, 214)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(75, 23)
        Me.btnDisplay.TabIndex = 2
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(183, 214)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(321, 214)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.GroupBox)
        Me.Name = "Form1"
        Me.Text = "Display"
        Me.GroupBox.ResumeLayout(False)
        Me.GroupBox.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox As GroupBox
    Friend WithEvents txtPrinciple As TextBox
    Friend WithEvents lblPrinciple As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtInterest As TextBox
    Friend WithEvents txtYears As TextBox
    Friend WithEvents lblYears As Label
    Friend WithEvents txtCompounds As TextBox
    Friend WithEvents lblCompounds As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
